package com.example.medicalmanagementsystem;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DoctorProfileActivity extends AppCompatActivity {

    EditText etDoctorId;
    Button btnFetchProfile;
    TextView tvDoctorProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        etDoctorId = findViewById(R.id.etDoctorId);
        btnFetchProfile = findViewById(R.id.btnFetchProfile);
        tvDoctorProfile = findViewById(R.id.tvDoctorProfile);

        btnFetchProfile.setOnClickListener(v -> {
            String doctorId = etDoctorId.getText().toString().trim();
            if (doctorId.isEmpty()) {
                Toast.makeText(this, "Please enter Doctor ID", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("Doctors") // assuming doctors are stored under "Doctors"
                    .child(doctorId);

            ref.get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult().exists()) {
                    DataSnapshot snapshot = task.getResult();
                    String name = snapshot.child("name").getValue(String.class);
                    String specialty = snapshot.child("specialty").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);

                    String profileInfo = "Name: " + name + "\n"
                            + "Specialty: " + specialty + "\n"
                            + "Email: " + email + "\n"
                            + "Phone: " + phone;
                    tvDoctorProfile.setText(profileInfo);
                } else {
                    tvDoctorProfile.setText("Doctor profile not found.");
                }
            });
        });
    }
}
