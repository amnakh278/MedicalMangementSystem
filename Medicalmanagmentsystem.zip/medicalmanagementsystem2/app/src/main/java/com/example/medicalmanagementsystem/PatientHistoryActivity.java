package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PatientHistoryActivity extends AppCompatActivity {

    EditText etDoctorId;
    Button btnLoadHistory;
    RecyclerView recyclerView;
    ArrayList<Treatment> treatmentList;
    TreatmentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_history);

        etDoctorId = findViewById(R.id.etDoctorId);
        btnLoadHistory = findViewById(R.id.btnLoadHistory);
        recyclerView = findViewById(R.id.recyclerHistory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        treatmentList = new ArrayList<>();
        adapter = new TreatmentAdapter(this, treatmentList);
        recyclerView.setAdapter(adapter);

        btnLoadHistory.setOnClickListener(v -> {
            String doctorId = etDoctorId.getText().toString().trim();
            if (TextUtils.isEmpty(doctorId)) {
                Toast.makeText(this, "Enter Doctor ID", Toast.LENGTH_SHORT).show();
            } else {
                loadTreatmentHistory(doctorId);
            }
        });
    }

    private void loadTreatmentHistory(String doctorId) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Patients");

        treatmentList.clear();

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot patientsSnapshot) {
                for (DataSnapshot patientSnapshot : patientsSnapshot.getChildren()) {
                    DataSnapshot treatmentsSnapshot = patientSnapshot.child("Treatments");

                    for (DataSnapshot treatmentSnap : treatmentsSnapshot.getChildren()) {
                        Treatment treatment = treatmentSnap.getValue(Treatment.class);
                        if (treatment != null && doctorId.equals(treatment.doctorId)) {
                            treatmentList.add(treatment);
                        }
                    }
                }

                if (treatmentList.isEmpty()) {
                    Toast.makeText(PatientHistoryActivity.this, "No treatments found for Doctor ID", Toast.LENGTH_SHORT).show();
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PatientHistoryActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
