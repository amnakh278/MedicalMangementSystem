package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PatientHomeActivity extends AppCompatActivity {

    EditText etPatientIdInput;
    Button btnLoadPatient;
    TextView tvName, tvAge, tvContact, tvGender;
    DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);

        etPatientIdInput = findViewById(R.id.etPatientIdInput); // You must add this EditText in XML
        btnLoadPatient = findViewById(R.id.btnLoadPatient);     // You must add this Button in XML

        tvName = findViewById(R.id.tvPaitientName);
        tvAge = findViewById(R.id.tvPaitientAge);
        tvContact = findViewById(R.id.tvPaitientContact);
        tvGender = findViewById(R.id.tvPaitientGender);

        btnLoadPatient.setOnClickListener(v -> {
            String patientId = etPatientIdInput.getText().toString().trim();

            if (patientId.isEmpty()) {
                Toast.makeText(this, "Please enter a Patient ID", Toast.LENGTH_SHORT).show();
                return;
            }

            loadPatientData(patientId);
        });
    }

    private void loadPatientData(String patientId) {
        databaseRef = FirebaseDatabase.getInstance().getReference("Patients").child(patientId);

        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Patient patient = snapshot.getValue(Patient.class);
                    if (patient != null) {
                        tvName.setText("Name: " + patient.getName());
                        tvAge.setText("Age: " + patient.getAge());
                        tvContact.setText("Contact: " + patient.getContact());
                        tvGender.setText("Gender: " + patient.getGender());
                    }
                } else {
                    Toast.makeText(PatientHomeActivity.this, "Patient not found", Toast.LENGTH_SHORT).show();
                    tvName.setText("");
                    tvAge.setText("");
                    tvContact.setText("");
                    tvGender.setText("");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(PatientHomeActivity.this, "Failed to load data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
