package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class HistoryUpdateActivity extends AppCompatActivity {

    private EditText etPatientId, etDoctorId, etDisease, etPrescription, etProgress;
    private Button btnUpdateTreatment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_update);

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        // Bind UI elements
        etPatientId = findViewById(R.id.etPatientId);
        etDoctorId = findViewById(R.id.etDoctorId);
        etDisease = findViewById(R.id.etDisease);
        etPrescription = findViewById(R.id.etPrescription);
        etProgress = findViewById(R.id.etProgress);
        btnUpdateTreatment = findViewById(R.id.btnUpdateTreatment);

        btnUpdateTreatment.setOnClickListener(view -> updateTreatment());
    }

    private void updateTreatment() {
        String patientId = etPatientId.getText().toString().trim();
        String doctorId = etDoctorId.getText().toString().trim();
        String disease = etDisease.getText().toString().trim();
        String prescription = etPrescription.getText().toString().trim();
        String progress = etProgress.getText().toString().trim();

        if (TextUtils.isEmpty(patientId) || TextUtils.isEmpty(doctorId)
                || TextUtils.isEmpty(disease) || TextUtils.isEmpty(prescription)
                || TextUtils.isEmpty(progress)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Treatment treatment = new Treatment(patientId, doctorId, disease, prescription, progress);

        DatabaseReference treatmentRef = FirebaseDatabase.getInstance()
                .getReference("Patients")
                .child(patientId)
                .child("Treatments")
                .push();  // Auto-generated treatment ID

        treatmentRef.setValue(treatment)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Treatment saved successfully", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
