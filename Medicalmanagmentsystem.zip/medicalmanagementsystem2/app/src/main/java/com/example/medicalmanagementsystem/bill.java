package com.example.medicalmanagementsystem;

public class bill {
    public String amount;
    public String date;
    public String status;

    // Default constructor (required for Firebase)
    public bill() {}

    // This is the constructor you're trying to use in your Activity
    public bill(String amount, String date, String status) {
        this.amount = amount;
        this.date = date;
        this.status = status;
    }
}



