package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class TodaysAppointmentActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Appointment> todaysAppointments;
    TodaysAppointmentAdapter adapter;
    EditText etDoctorId;
    Button btnTodaysAppointment;

    private static final String TAG = "TodaysAppointment";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_appointments);

        etDoctorId = findViewById(R.id.etDoctorId);
        btnTodaysAppointment = findViewById(R.id.btnFetchAppointments);
        recyclerView = findViewById(R.id.recyclerPendingAppointments);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        todaysAppointments = new ArrayList<>();
        adapter = new TodaysAppointmentAdapter(this, todaysAppointments);
        recyclerView.setAdapter(adapter);

        btnTodaysAppointment.setOnClickListener(v -> {
            String doctorId = etDoctorId.getText().toString().trim();
            if (doctorId.isEmpty()) {
                Toast.makeText(this, "Enter Doctor ID", Toast.LENGTH_SHORT).show();
                return;
            }
            fetchTodaysAppointments(doctorId);
        });
    }

    private void fetchTodaysAppointments(String doctorId) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Log.d(TAG, "Fetching for date: " + today + " and doctor ID: " + doctorId);

        DatabaseReference patientsRef = FirebaseDatabase.getInstance().getReference("Patients");
        patientsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                todaysAppointments.clear();

                for (DataSnapshot patientSnapshot : snapshot.getChildren()) {
                    if (!patientSnapshot.hasChild("Appointments")) continue;

                    DataSnapshot appointmentsNode = patientSnapshot.child("Appointments");

                    for (DataSnapshot appointmentSnapshot : appointmentsNode.getChildren()) {
                        Appointment appt = appointmentSnapshot.getValue(Appointment.class);

                        if (appt == null || appt.appointmentDate == null || appt.doctorId == null) {
                            Log.w(TAG, "Skipping invalid appointment in patient: " + patientSnapshot.getKey());
                            continue;
                        }

                        Log.d(TAG, "Checking appointment: " + appointmentSnapshot.getKey() +
                                ", Date: " + appt.appointmentDate +
                                ", Doctor ID: " + appt.doctorId);

                        if (appt.appointmentDate.trim().equals(today) &&
                                appt.doctorId.trim().equalsIgnoreCase(doctorId)) {
                            appt.id = appointmentSnapshot.getKey(); // Optional
                            todaysAppointments.add(appt);
                        }
                    }
                }

                adapter.notifyDataSetChanged();

                if (todaysAppointments.isEmpty()) {
                    Toast.makeText(TodaysAppointmentActivity.this,
                            "No appointments found for today and doctor ID: " + doctorId,
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TodaysAppointmentActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Firebase error", error.toException());
            }
        });
    }
}
