package com.example.medicalmanagementsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TreatmentAdapter extends RecyclerView.Adapter<TreatmentAdapter.TreatmentViewHolder> {

    Context context;
    ArrayList<Treatment> treatmentList;

    public TreatmentAdapter(Context context, ArrayList<Treatment> treatmentList) {
        this.context = context;
        this.treatmentList = treatmentList;
    }

    @Override
    public int getItemViewType(int position) {
        // Example logic (customize as per your use case)
        // Return 0 for one layout, 1 for the other
        return position % 2 == 0 ? 0 : 1; // Or use treatmentList.get(position).type
    }
    @NonNull
    @Override
    public TreatmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == 0) {
            view = LayoutInflater.from(context).inflate(R.layout.item_treatment, parent, false);
        } else {
            view = LayoutInflater.from(context).inflate(R.layout.item_history, parent, false);
        }
        return new TreatmentViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull TreatmentViewHolder holder, int position) {
        Treatment treatment = treatmentList.get(position);
        holder.tvPatientId.setText("Patient ID: " + treatment.patientId);
        holder.tvDoctorId.setText("Doctor ID: " + treatment.doctorId);
        holder.tvDisease.setText("Disease: " + treatment.disease);
        holder.tvPrescription.setText("Prescription: " + treatment.prescription);
        holder.tvProgress.setText("Progress: " + treatment.progress);
    }

    @Override
    public int getItemCount() {
        return treatmentList.size();
    }

    public static class TreatmentViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientId, tvDoctorId, tvDisease, tvPrescription, tvProgress;

        public TreatmentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientId = itemView.findViewById(R.id.tvPatientId);
            tvDoctorId = itemView.findViewById(R.id.tvDoctorId);
            tvDisease = itemView.findViewById(R.id.tvDisease);
            tvPrescription = itemView.findViewById(R.id.tvPrescription);
            tvProgress = itemView.findViewById(R.id.tvProgress);
        }
    }


}
