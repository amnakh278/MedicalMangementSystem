package com.example.medicalmanagementsystem;

public class Appointment {
    public String id; // Firebase key
    public String patientName;
    public String doctorId;
    public String appointmentDate;
    public String status;

    // Default constructor required for Firebase
    public Appointment() {}

    // Constructor without status (defaults to "Pending")
    public Appointment(String patientName, String doctorId, String appointmentDate) {
        this.patientName = patientName;
        this.doctorId = doctorId;
        this.appointmentDate = appointmentDate;
        this.status = "Pending";
    }

    // Constructor with status
    public Appointment(String patientName, String doctorId, String appointmentDate, String status) {
        this.patientName = patientName;
        this.doctorId = doctorId;
        this.appointmentDate = appointmentDate;
        this.status = status;
    }
}
