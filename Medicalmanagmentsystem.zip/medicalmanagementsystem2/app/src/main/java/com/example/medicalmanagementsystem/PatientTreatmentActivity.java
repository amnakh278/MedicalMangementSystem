package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PatientTreatmentActivity extends AppCompatActivity {

    EditText etPatientIdInput;
    Button btnLoadTreatment;
    RecyclerView recyclerView;
    ArrayList<Treatment> treatmentList;
    TreatmentAdapter treatmentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_treatment);

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        // UI setup
        etPatientIdInput = findViewById(R.id.etPatientId);
        btnLoadTreatment = findViewById(R.id.btnViewtreatments);
        recyclerView = findViewById(R.id.item_treatment);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        treatmentList = new ArrayList<>();
        treatmentAdapter = new TreatmentAdapter(this, treatmentList);
        recyclerView.setAdapter(treatmentAdapter);

        btnLoadTreatment.setOnClickListener(v -> {
            String patientId = etPatientIdInput.getText().toString().trim();
            if (patientId.isEmpty()) {
                Toast.makeText(this, "Please enter a Patient ID", Toast.LENGTH_SHORT).show();
                return;
            }
            loadTreatments(patientId);
        });
    }

    private void loadTreatments(String patientId) {
        DatabaseReference treatmentRef = FirebaseDatabase.getInstance()
                .getReference("Patients")
                .child(patientId)
                .child("Treatments");

        treatmentRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                treatmentList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot treatmentSnapshot : snapshot.getChildren()) {
                        Treatment treatment = treatmentSnapshot.getValue(Treatment.class);
                        if (treatment != null) {
                            treatmentList.add(treatment);
                        }
                    }
                    if (treatmentList.isEmpty()) {
                        Toast.makeText(PatientTreatmentActivity.this, "No treatments found for this patient.", Toast.LENGTH_SHORT).show();
                        recyclerView.setVisibility(View.GONE);
                    } else {
                        treatmentAdapter.notifyDataSetChanged();
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                } else {
                    Toast.makeText(PatientTreatmentActivity.this, "No data found for patient ID: " + patientId, Toast.LENGTH_SHORT).show();
                    recyclerView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PatientTreatmentActivity.this, "Firebase error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
