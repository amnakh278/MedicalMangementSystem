package com.example.medicalmanagementsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.BillViewHolder> {

    Context context;
    ArrayList<bill> billLists;

    public Adapter(Context context, ArrayList<bill> billList) {
        this.context = context;
        this.billLists = billList;
    }

    @NonNull
    @Override
    public BillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_bill, parent, false);
        return new BillViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BillViewHolder holder, int position) {
        bill bill = billLists.get(position);
        holder.tvAmount.setText("Amount: ₹" + bill.amount);
        holder.tvDate.setText("Date: " + bill.date);
        holder.tvStatus.setText("Status: " + bill.status);
    }

    @Override
    public int getItemCount() {
        return billLists.size();
    }

    public static class BillViewHolder extends RecyclerView.ViewHolder {
        TextView tvAmount, tvDate, tvStatus;

        public BillViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
