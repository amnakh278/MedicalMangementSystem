package com.example.medicalmanagementsystem;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class TodaysAppointmentAdapter extends RecyclerView.Adapter<TodaysAppointmentAdapter.ViewHolder> {

    Context context;
    ArrayList<Appointment> list;

    public TodaysAppointmentAdapter(Context context, ArrayList<Appointment> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_todays_appointment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Appointment appointment = list.get(position);
        holder.txtPatientName.setText("Patient: " + appointment.patientName);
        holder.txtDoctorId.setText("Doctor ID: " + appointment.doctorId);
        holder.txtDate.setText("Date: " + appointment.appointmentDate);
        holder.txtStatus.setText("Status: " + appointment.status);

        holder.btnAccept.setOnClickListener(v -> {
            FirebaseDatabase.getInstance().getReference("Appointments")
                    .child(appointment.id).child("status").setValue("Accepted");
            Toast.makeText(context, "Accepted", Toast.LENGTH_SHORT).show();
            appointment.status = "Accepted";
            notifyItemChanged(position);
        });

        holder.btnReject.setOnClickListener(v -> {
            FirebaseDatabase.getInstance().getReference("Appointments")
                    .child(appointment.id).child("status").setValue("Rejected");
            Toast.makeText(context, "Rejected", Toast.LENGTH_SHORT).show();
            appointment.status = "Rejected";
            notifyItemChanged(position);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtPatientName, txtDoctorId, txtDate, txtStatus;
        Button btnAccept, btnReject;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtPatientName = itemView.findViewById(R.id.txtPatientName);
            txtDoctorId = itemView.findViewById(R.id.txtDoctorId);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            btnAccept = itemView.findViewById(R.id.btnAccept);
            btnReject = itemView.findViewById(R.id.btnReject);
        }
    }
}
