package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class PatientAppointmentActivity extends AppCompatActivity {

    EditText etPatientId, etPatientName, etDoctorId, etAppointmentDate;
    Button btnBookAppointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment);

        etPatientId = findViewById(R.id.PatientId);
        etPatientName = findViewById(R.id.PatientName);
        etDoctorId = findViewById(R.id.DoctorId);
        etAppointmentDate = findViewById(R.id.AppointmentDate);
        btnBookAppointment = findViewById(R.id.btnBookAppointment);

        btnBookAppointment.setOnClickListener(v -> {
            String patientId = etPatientId.getText().toString().trim();
            String patientName = etPatientName.getText().toString().trim();
            String doctorId = etDoctorId.getText().toString().trim();
            String date = etAppointmentDate.getText().toString().trim();

            if (patientId.isEmpty() || patientName.isEmpty() || doctorId.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate date format
            if (!isValidDateFormat(date)) {
                Toast.makeText(this, "Date must be in yyyy-MM-dd format (e.g., 2025-06-06)", Toast.LENGTH_LONG).show();
                return;
            }

            DatabaseReference patientRef = FirebaseDatabase.getInstance()
                    .getReference("Patients")
                    .child(patientId);

            patientRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        Appointment appointment = new Appointment(patientName, doctorId, date, "Pending");

                        DatabaseReference appointmentRef = patientRef.child("Appointments");
                        String id = appointmentRef.push().getKey();

                        appointmentRef.child(id).setValue(appointment).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(PatientAppointmentActivity.this, "Appointment booked successfully", Toast.LENGTH_SHORT).show();
                                etPatientId.setText("");
                                etPatientName.setText("");
                                etDoctorId.setText("");
                                etAppointmentDate.setText("");
                            } else {
                                Toast.makeText(PatientAppointmentActivity.this, "Failed to book appointment", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Toast.makeText(PatientAppointmentActivity.this, "Patient ID not found!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Toast.makeText(PatientAppointmentActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // Function to validate date format
    private boolean isValidDateFormat(String dateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            sdf.setLenient(false); // strict checking
            sdf.parse(dateStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
