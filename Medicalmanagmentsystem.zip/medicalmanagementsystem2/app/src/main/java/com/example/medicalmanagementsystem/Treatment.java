package com.example.medicalmanagementsystem;

public class Treatment {
    public String patientId;
    public String doctorId;
    public String disease;
    public String prescription;
    public String progress;

    public Treatment() {}

    public Treatment(String patientId, String doctorId, String disease, String prescription, String progress) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.disease = disease;
        this.prescription = prescription;
        this.progress = progress;
    }
}
