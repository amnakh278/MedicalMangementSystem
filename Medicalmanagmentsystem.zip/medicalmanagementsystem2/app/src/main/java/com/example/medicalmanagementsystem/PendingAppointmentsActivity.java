package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.*;

import java.util.ArrayList;

public class PendingAppointmentsActivity extends AppCompatActivity {

    EditText etDoctorId;
    Button btnFetchAppointments;
    RecyclerView recyclerView;
    ArrayList<Appointment> pendingAppointments;
    AppointmentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_appointments);

        etDoctorId = findViewById(R.id.etDoctorId);
        btnFetchAppointments = findViewById(R.id.btnFetchAppointments);
        recyclerView = findViewById(R.id.recyclerPendingAppointments);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        pendingAppointments = new ArrayList<>();
        adapter = new AppointmentAdapter(this, pendingAppointments);
        recyclerView.setAdapter(adapter);

        btnFetchAppointments.setOnClickListener(v -> {
            String doctorId = etDoctorId.getText().toString().trim();
            if (doctorId.isEmpty()) {
                Toast.makeText(this, "Enter Doctor ID", Toast.LENGTH_SHORT).show();
                return;
            }
            fetchPendingAppointments(doctorId);
        });
    }

    private void fetchPendingAppointments(String doctorId) {
        DatabaseReference patientsRef = FirebaseDatabase.getInstance().getReference("Patients");

        pendingAppointments.clear();

        patientsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot patientSnap : snapshot.getChildren()) {
                    DataSnapshot appointmentsSnap = patientSnap.child("Appointments");

                    for (DataSnapshot apptSnap : appointmentsSnap.getChildren()) {
                        Appointment appt = apptSnap.getValue(Appointment.class);

                        if (appt != null &&
                                appt.doctorId != null &&
                                appt.status != null &&
                                appt.doctorId.equals(doctorId) &&
                                appt.status.equalsIgnoreCase("Pending")) {

                            pendingAppointments.add(appt);
                        }
                    }
                }

                if (pendingAppointments.isEmpty()) {
                    Toast.makeText(PendingAppointmentsActivity.this, "No pending appointments", Toast.LENGTH_SHORT).show();
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PendingAppointmentsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
