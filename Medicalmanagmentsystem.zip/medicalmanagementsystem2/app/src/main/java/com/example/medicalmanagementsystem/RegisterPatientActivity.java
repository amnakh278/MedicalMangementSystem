package com.example.medicalmanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Logger;

import java.util.HashMap;
import java.util.Map;

public class RegisterPatientActivity extends AppCompatActivity {

    EditText etId, etName, etAge, etContact, etGender;
    Button btnRegister;
    DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_patient);

        etId = findViewById(R.id.etPatientId); // Add EditText for manual ID in XML
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etContact = findViewById(R.id.etContact);
        etGender = findViewById(R.id.etGender);
        btnRegister = findViewById(R.id.btnRegister);

        FirebaseDatabase.getInstance().setLogLevel(Logger.Level.DEBUG);
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://medicalmanagementsystem123-default-rtdb.firebaseio.com/");
        databaseRef = database.getReference("Patients");

        btnRegister.setOnClickListener(v -> {
            String id = etId.getText().toString().trim();
            String name = etName.getText().toString().trim();
            String age = etAge.getText().toString().trim();
            String contact = etContact.getText().toString().trim();
            String gender = etGender.getText().toString().trim();

            if (id.isEmpty() || name.isEmpty() || age.isEmpty() || contact.isEmpty() || gender.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Use HashMap if you want to avoid using a model class
            Map<String, Object> patientMap = new HashMap<>();
            patientMap.put("patientId", id);
            patientMap.put("name", name);
            patientMap.put("age", age);
            patientMap.put("contact", contact);
            patientMap.put("gender", gender);

            databaseRef.child(id).setValue(patientMap)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Patient Registered", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(RegisterPatientActivity.this, PatientHomeActivity.class);
                        i.putExtra("patientId", id);
                        startActivity(i);
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }
}

