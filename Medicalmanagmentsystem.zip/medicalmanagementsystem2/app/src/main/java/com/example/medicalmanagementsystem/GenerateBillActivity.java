package com.example.medicalmanagementsystem;


import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class GenerateBillActivity extends AppCompatActivity {

    private EditText etPatientId, etAmount, etDate, etStatus;
    private Button btnGenerateBill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_bill);

        FirebaseApp.initializeApp(this);

        etPatientId = findViewById(R.id.etPatientId);
        etAmount = findViewById(R.id.etAmount);
        etDate = findViewById(R.id.etDate);
        etStatus = findViewById(R.id.etStatus);
        btnGenerateBill = findViewById(R.id.btnGenerateBill);

        btnGenerateBill.setOnClickListener(v -> generateBill());
    }

    private void generateBill() {
        String patientId = etPatientId.getText().toString().trim();
        String amount = etAmount.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String status = etStatus.getText().toString().trim();

        if (TextUtils.isEmpty(patientId) || TextUtils.isEmpty(amount) ||
                TextUtils.isEmpty(date) || TextUtils.isEmpty(status)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        bill billObj = new bill(amount, date, status);

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Patients")
                .child(patientId)
                .child("Bills")
                .push(); // Generates dynamic bill ID

        ref.setValue(billObj)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Bill generated successfully", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
