package com.example.medicalmanagementsystem;

public class Patient {

    public String patientId;
    public String name;
    public String age;
    public String contact;
    public String gender;

    // Required empty constructor for Firebase
    public Patient() {
    }

    // Constructor to initialize all fields
    public Patient(String patientId, String name, String age, String contact, String gender) {
        this.patientId = patientId;
        this.name = name;
        this.age = age;
        this.contact = contact;
        this.gender = gender;
    }

    // Optional: getters and setters
    public String getPatientId() { return patientId; }
    public void setPatientId(String patientId) { this.patientId = patientId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
}


