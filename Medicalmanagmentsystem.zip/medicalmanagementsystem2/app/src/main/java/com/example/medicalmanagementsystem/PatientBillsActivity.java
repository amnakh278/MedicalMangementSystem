package com.example.medicalmanagementsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PatientBillsActivity extends AppCompatActivity {

    EditText etPatientIdInput;
    Button btnLoadBills;
    RecyclerView recyclerView;
    ArrayList<bill> billLists;
    Adapter billAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_bills);

        etPatientIdInput = findViewById(R.id.etPatientId);
        btnLoadBills = findViewById(R.id.btnViewBills);
        recyclerView = findViewById(R.id.recycler_bills);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        billLists = new ArrayList<>();
        billAdapter = new Adapter(this, billLists);
        recyclerView.setAdapter(billAdapter);

        btnLoadBills.setOnClickListener(v -> {
            String patientId = etPatientIdInput.getText().toString().trim();
            if (patientId.isEmpty()) {
                Toast.makeText(this, "Please enter a Patient ID", Toast.LENGTH_SHORT).show();
                return;
            }
            loadBills(patientId);
        });
    }

    private void loadBills(String patientId) {
        DatabaseReference billsRef = FirebaseDatabase.getInstance()
                .getReference("Patients")
                .child(patientId)
                .child("Bills");

        billsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                billLists.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot billSnapshot : snapshot.getChildren()) {
                        String amount = billSnapshot.child("amount").getValue(String.class);
                        String date = billSnapshot.child("date").getValue(String.class);
                        String status = billSnapshot.child("status").getValue(String.class);

                        bill b = new bill(amount, date, status);
                        billLists.add(b);
                    }
                    recyclerView.setVisibility(View.VISIBLE);
                    billAdapter.notifyDataSetChanged();
                    Toast.makeText(PatientBillsActivity.this, "Bills loaded: " + billLists.size(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PatientBillsActivity.this, "No bills found for patient ID: " + patientId, Toast.LENGTH_SHORT).show();
                    billAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PatientBillsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
