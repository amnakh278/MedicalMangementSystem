package com.example.medicalmanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnRegisterPatient, btnViewBills, btnViewHome, btnOpenTreatment, btnAppointment, btnDoctorProfile, btnPendingAppointments, btnTodaysAppointment, btnHistoryUpdate, btnGenerateBill, btnViewHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRegisterPatient = findViewById(R.id.btnRegisterPatient);
        btnViewBills = findViewById(R.id.btnViewBills);
        btnViewHome= findViewById(R.id.btnViewHome);
        btnOpenTreatment=findViewById(R.id.btnOpenTreatment);
        btnAppointment = findViewById(R.id.btnAppointment);
        btnDoctorProfile = findViewById(R.id.btnDoctorProfile);
        btnPendingAppointments = findViewById(R.id.btnPendingAppointments);
        btnTodaysAppointment = findViewById(R.id.btnTodaysAppointment);
        btnHistoryUpdate = findViewById(R.id.btnHistoryUpdate);
        btnGenerateBill = findViewById(R.id.btnGenerateBill);
        btnViewHistory = findViewById(R.id.btnViewHistory);
        btnRegisterPatient.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterPatientActivity.class);
            startActivity(intent);
        });

        btnViewBills.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PatientBillsActivity.class);
            startActivity(intent);
        });
        btnViewHome.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PatientHomeActivity.class);
            startActivity(intent);
        });
        btnOpenTreatment.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PatientTreatmentActivity.class);
            startActivity(intent);
        });
        btnAppointment.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PatientAppointmentActivity.class);
            startActivity(intent);
        });
        btnDoctorProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DoctorProfileActivity.class);
            startActivity(intent);
        });
        btnPendingAppointments.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PendingAppointmentsActivity.class);
            startActivity(intent);
        });
        btnTodaysAppointment.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TodaysAppointmentActivity.class);
            startActivity(intent);
        });
        btnHistoryUpdate.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HistoryUpdateActivity.class);
            startActivity(intent);
        });
        btnGenerateBill.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, GenerateBillActivity.class);
            startActivity(intent);
        });
        btnViewHistory.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PatientHistoryActivity.class);
            startActivity(intent);
        });
    }


}
